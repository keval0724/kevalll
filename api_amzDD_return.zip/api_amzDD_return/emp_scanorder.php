<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

include('db.php');
header('Content-Type: application/json');

try {
    // ✅ Check Required Fields
    if (!isset($_POST['id']) || !isset($_POST['return_tracking_id']) || !isset($_POST['bad_good_return'])) {
        throw new Exception("Missing required parameters");
    }

    $id = intval($_POST['id']);
    $return_tracking_id = trim($_POST['return_tracking_id']);
    $bad_good_return = trim($_POST['bad_good_return']);
    $status = "completed";
    $image_urls = [];

    // ✅ Debugging: Check $_FILES Data
    error_log("FILES DATA: " . print_r($_FILES, true));

    // ✅ Handle Image Upload Only If "bad_good_return" is "bad"
    if ($bad_good_return === "bad" && isset($_FILES['images']) && is_array($_FILES['images']['tmp_name'])) {
        $upload_dir = "/var/www/customprint.deodap.com/uploads/";

        // Ensure upload directory exists
        if (!is_dir($upload_dir) && !mkdir($upload_dir, 0777, true)) {
            throw new Exception("Failed to create upload directory.");
        }   

        // ✅ Check If Directory Is Writable
        if (!is_writable($upload_dir)) {
            throw new Exception("Upload directory is not writable.");
        }

        // ✅ Loop through uploaded images
        foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            if (!empty($tmp_name)) {
                // ✅ Check if there was an upload error
                if ($_FILES['images']['error'][$key] !== UPLOAD_ERR_OK) {
                    throw new Exception("File upload error: " . $_FILES['images']['error'][$key]);
                }

                // ✅ Generate unique filename
                $file_name = time() . "_" . basename($_FILES['images']['name'][$key]);
                $target_file = $upload_dir . $file_name;
                
                // ✅ Move file to upload directory
                if (move_uploaded_file($tmp_name, $target_file)) {
                    $image_urls[] = "https://customprint.deodap.com/uploads/" . $file_name;
                } else {
                    throw new Exception("Failed to move uploaded file: " . $target_file);
                }
            }
        }
    }

    // ✅ Convert image URLs to JSON format for database storage
    $image_json = !empty($image_urls) ? json_encode($image_urls, JSON_UNESCAPED_SLASHES) : null;
    error_log("Image URLs JSON: " . $image_json);

    // ✅ Update Database
    $query = "UPDATE order_tracking SET status = ?, images = ?, bad_good_return = ? WHERE id = ? AND return_tracking_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssis", $status, $image_json, $bad_good_return, $id, $return_tracking_id);

    if ($stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Order updated successfully",
            "status" => $status,
            "return_tracking_id" => $return_tracking_id,
            "bad_good_return" => $bad_good_return,
            "uploaded_images" => $image_urls
        ]);
    } else {
        throw new Exception("Failed to update order: " . $stmt->error);
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
