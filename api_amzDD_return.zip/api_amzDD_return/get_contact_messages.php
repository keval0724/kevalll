<?php
$servername = "lms.cpcm5mpbdjt1.ap-south-1.rds.amazonaws.com";
$username = "vc01";
$password = "Yx6Nbs0fer5gXLY";
$dbname = "admin_amzDDreturn_deodap_com";

header('Content-Type: application/json');

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

$sql = "SELECT id, name, message, created_at FROM contact_form ORDER BY id DESC";
$result = $conn->query($sql);

$messages = [];

while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

echo json_encode(["success" => true, "messages" => $messages]);
$conn->close();
?>
