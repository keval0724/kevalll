<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

include('db.php');
header('Content-Type: application/json');

try {
    if (!isset($_GET['seller_id'])) {
        throw new Exception("Missing required parameter: seller_id");
    }
    
    $seller_id = intval($_GET['seller_id']);
    $filter = isset($_GET['filter']) ? strtolower(trim($_GET['filter'])) : '';

    // ✅ Base Query
    $query = "SELECT return_tracking_id, amazon_order_id, otp, bad_good_return, images, seller_name, status, created_at 
              FROM order_tracking 
              WHERE seller_id = ? AND status = 'completed'";

    // ✅ Add Dynamic Filter
    $params = [$seller_id];  // Array for dynamic parameters
    $types  = "i";  // `seller_id` integer hai

    if ($filter === 'good' || $filter === 'bad') {
        $query .= " AND LOWER(TRIM(bad_good_return)) = ?";
        $params[] = $filter; 
        $types   .= "s";  // `bad_good_return` string hai
    }

    // 🔹 Debugging ke liye query log karein
    error_log("SQL Query: " . $query);

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("SQL Error: " . $conn->error);
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $row['images'] = $row['images'] ? json_decode($row['images'], true) : [];
        $row['bad_good_return'] = trim(strtolower($row['bad_good_return'] ?? '')); // ✅ Ensure clean value
        $orders[] = $row;
    }

    // ✅ Extract Seller Name
    $seller_name = "";
    if (!empty($orders)) {
        $seller_name = $orders[0]['seller_name'];
        foreach ($orders as &$order) {
            unset($order['seller_name']); // Remove seller_name from each order
        }
    } else {
        throw new Exception("No completed orders found for this seller or incorrect filter value");
    }

    echo json_encode([
        "success"        => true,
        "seller_id"      => $seller_id,
        "seller_name"    => $seller_name,
        "scanned_orders" => $orders
    ], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
