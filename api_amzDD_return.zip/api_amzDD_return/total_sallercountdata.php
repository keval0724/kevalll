<?php
// Set timezone and headers
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// Include DB connection
require_once('db.php');

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    // Get total unique sellers
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT seller_id) AS total_sellers FROM order_tracking");
    $stmt->execute();
    $result = $stmt->get_result();
    $total_sellers = (int) ($result->fetch_assoc()['total_sellers'] ?? 0);
    $stmt->close();

    // Get total orders (non-empty Amazon order IDs)
    $stmt = $conn->prepare("SELECT COUNT(*) AS total_orders FROM order_tracking WHERE amazon_order_id IS NOT NULL AND amazon_order_id != ''");
    $stmt->execute();
    $result = $stmt->get_result();
    $total_orders = (int) ($result->fetch_assoc()['total_orders'] ?? 0);
    $stmt->close();

    // Get total tracking IDs
    $stmt = $conn->prepare("SELECT COUNT(return_tracking_id) AS total_tracking_ids FROM order_tracking");
    $stmt->execute();
    $result = $stmt->get_result();
    $total_tracking_ids = (int) ($result->fetch_assoc()['total_tracking_ids'] ?? 0);
    $stmt->close();

    // Get pending, completed, OTP count
    $stmt = $conn->prepare("
        SELECT 
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS total_pending,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS total_completed,
            COUNT(otp) AS total_otp_count
        FROM order_tracking
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    $total_pending = (int) ($row['total_pending'] ?? 0);
    $total_completed = (int) ($row['total_completed'] ?? 0);
    $total_otp_count = (int) ($row['total_otp_count'] ?? 0);

    // Output JSON response
    echo json_encode([
        "success" => true,
        "data" => [
            "total_sellers" => $total_sellers,
            "total_orders" => $total_orders,
            "total_tracking_ids" => $total_tracking_ids,
            "total_pending" => $total_pending,
            "total_completed" => $total_completed,
            "total_otp_count" => $total_otp_count
        ]
    ]);
    exit;

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
    exit;
}
