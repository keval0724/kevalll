<?php
require_once('db.php'); // External DB config file
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "status" => "error",
        "message" => "Only POST method is allowed."
    ]);
    exit;
}

// Get input
$name = trim($_POST['name'] ?? '');
$message = trim($_POST['message'] ?? '');

// Validate input
if (empty($name) || empty($message)) {
    echo json_encode([
        "status" => "error",
        "message" => "Name and message are required."
    ]);
    exit;
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO contact_form (name, message) VALUES (?, ?)");
$stmt->bind_param("ss", $name, $message);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Form submitted successfully."
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to submit form."
        // Uncomment for debugging only:
        // "sql_error" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
exit;
