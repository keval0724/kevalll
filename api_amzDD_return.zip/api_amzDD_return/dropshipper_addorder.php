<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');

include('db.php');

try {
    // ✅ Required field check
    if (
        !isset(
            $_POST['seller_id'],
            $_POST['amazon_order_ids'], 
            $_POST['return_tracking_ids'], 
            $_POST['otp'],
            $_POST['out_for_delivery_date']
        )
    ) {
        throw new Exception("Missing required fields.");
    }

    // ✅ Sanitize inputs
    $seller_id = trim($_POST['seller_id']);
    $amazon_order_ids = array_map('trim', explode(',', $_POST['amazon_order_ids']));
    $return_tracking_ids = array_map('trim', explode(',', $_POST['return_tracking_ids']));
    $otp = trim($_POST['otp']);
    $out_for_delivery_date = trim($_POST['out_for_delivery_date']);

    // ✅ Validate counts
    if (count($amazon_order_ids) !== count($return_tracking_ids)) {
        throw new Exception("Order IDs and Tracking IDs count mismatch.");
    }

    // ✅ OTP format check
    if (!preg_match('/^\d{3,6}$/', $otp)) {
        throw new Exception("OTP must be 3 to 6 digits.");
    }

    // ✅ Date format check
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $out_for_delivery_date)) {
        throw new Exception("Invalid date format. Use YYYY-MM-DD.");
    }

    // ✅ Duplicate tracking IDs in request
    if (count($return_tracking_ids) !== count(array_unique($return_tracking_ids))) {
        throw new Exception("Duplicate tracking IDs found in input.");
    }

    // ✅ Check seller and fetch seller_name + crn
    $stmt = $conn->prepare("SELECT seller_name, crn FROM dropshippers WHERE seller_id = ? LIMIT 1");
    $stmt->bind_param("s", $seller_id);
    $stmt->execute();
    $seller_check = $stmt->get_result();

    if ($seller_check->num_rows === 0) {
        throw new Exception("Seller not found.");
    }

    $seller_row = $seller_check->fetch_assoc();
    $seller_name = $seller_row['seller_name'];
    $crn = $seller_row['crn'];

    // ✅ Fast duplicate check in DB
    $placeholders = implode(',', array_fill(0, count($return_tracking_ids), '?'));
    $types = str_repeat('s', count($return_tracking_ids));
    $check = $conn->prepare("SELECT return_tracking_id FROM order_tracking WHERE return_tracking_id IN ($placeholders)");
    $check->bind_param($types, ...$return_tracking_ids);
    $check->execute();
    $result = $check->get_result();

    $duplicate_found = [];
    while ($row = $result->fetch_assoc()) {
        $duplicate_found[] = $row['return_tracking_id'];
    }

    if (!empty($duplicate_found)) {
        throw new Exception("These tracking IDs already exist: " . implode(', ', $duplicate_found));
    }

    // ✅ Insert all records (crn added here)
    $insert = $conn->prepare("
        INSERT INTO order_tracking 
        (seller_id, seller_name, crn, amazon_order_id, return_tracking_id, otp, out_for_delivery_date, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");

    if (!$insert) {
        throw new Exception("Insert prepare failed: " . $conn->error);
    }

    $conn->begin_transaction();

    for ($i = 0; $i < count($amazon_order_ids); $i++) {
        $insert->bind_param(
            "sssssss",
            $seller_id,
            $seller_name,
            $crn,
            $amazon_order_ids[$i],
            $return_tracking_ids[$i],
            $otp,
            $out_for_delivery_date
        );
        $insert->execute();
    }

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "Orders inserted successfully."
    ]);

} catch (Exception $e) {
    if ($conn->errno) {
        $conn->rollback();
    }

    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>
