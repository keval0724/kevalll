<?php
header("Content-Type: application/json");
date_default_timezone_set("Asia/Kolkata");

// --- Database credentials ---
$servername   = "lms.cpcm5mpbdjt1.ap-south-1.rds.amazonaws.com";
$db_username  = "vc01";
$db_password  = "Yx6Nbs0fer5gXLY";
$dbname       = "admin_amzDDreturn_deodap_com";

// --- Connect to database ---
$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed."]);
    exit;
}

// --- Read and decode input ---
$input = json_decode(file_get_contents("php://input"), true);
$username = trim($input['username'] ?? '');
$password = trim($input['password'] ?? '');
$crn      = trim($input['crn'] ?? '');

// --- Validate input ---
if (empty($username) || empty($password) || empty($crn)) {
    echo json_encode(["success" => false, "message" => "All fields are required."]);
    exit;
}

// --- Fetch user record ---
$stmt = $conn->prepare("SELECT * FROM dropshippers WHERE username = ? AND crn = ? LIMIT 1");
$stmt->bind_param("ss", $username, $crn);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // --- Verify password ---
    if (password_verify($password, $user['password'])) {
        // --- Update last login time ---
        $update = $conn->prepare("UPDATE dropshippers SET last_login = NOW() WHERE id = ?");
        $update->bind_param("i", $user['id']);
        $update->execute();

        echo json_encode([
            "success" => true,
            "message" => "Login successful.",
            "data" => [
                "id"             => $user['id'],
                "seller_id"      => $user['seller_id'],
                "username"       => $user['username'],
                "seller_name"    => $user['seller_name'],
                "store_name"     => $user['store_name'],
                "contact_number" => $user['contact_number'],
                "email"          => $user['email'],
                "crn"            => $user['crn'],
                "last_login"     => $user['last_login']
            ]
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["success" => false, "message" => "Invalid password."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid username or CRN."]);
}

$conn->close();
?>
