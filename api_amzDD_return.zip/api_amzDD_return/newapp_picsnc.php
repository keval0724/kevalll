<?php
header('Content-Type: application/json');

// Static response data
$response = [
    "success" => true,
    "screen" => [
        "link" => "No Link" // Replace with your actual link
    ]
];

// Return the response as JSON
echo json_encode($response);
?>
