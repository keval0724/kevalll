<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

require 'db.php';

$response = [];

$sql = "SELECT * FROM order_tracking ORDER BY id DESC";
$result = $conn->query($sql);

$orders = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = [
            'id' => $row['id'],
            'seller_id' => $row['seller_id'],
            'seller_name' => $row['seller_name'],
            'crn' =>$row['crn'],
            'amazon_order_id' => $row['amazon_order_id'],
            'return_tracking_id' => $row['return_tracking_id'],
            'otp' => $row['otp'],
            'out_for_delivery_date' => $row['out_for_delivery_date'],
            'status' => $row['status'],
            'bad_good_return' => $row['bad_good_return'],
            'images' => json_decode($row['images'] ?? '[]', true),
            'sticker_photo' => $row['sticker_photo'],
            'unbox_photo' => $row['unbox_photo'],
            'remarks' => $row['remarks'],
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
        ];
    }

    $response['status'] = 'success';
    $response['scanned_orders'] = $orders;
} else {
    $response['status'] = 'error';
    $response['message'] = 'No orders found.';
}

echo json_encode($response);
$conn->close();
