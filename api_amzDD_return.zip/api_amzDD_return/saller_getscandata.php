<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

include "db_config.php"; // Database connection file include karna

$seller_id = isset($_GET['seller_id']) ? $_GET['seller_id'] : null;

if (!$seller_id) {
    echo json_encode(["success" => false, "message" => "seller_id required"]);
    exit;
}

// Query to fetch completed orders for given seller_id
$query = "SELECT amazon_order_id, return_tracking_id, otp, status, bad_good_return, images 
          FROM order_tracking 
          WHERE seller_id = ? AND status = 'completed'";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$response = ["success" => true, "data" => []];

while ($row = $result->fetch_assoc()) {
    $orderData = [
        "amazon_order_id" => $row['amazon_order_id'],
        "return_tracking_id" => $row['return_tracking_id'],
        "otp" => $row['otp'],
        "status" => $row['status'],
        "good ya bad return" => ($row['bad_good_return'] == "good") ? "good" : "bad"
    ];

    // Agar return "bad" hai to images ka data bhi add karna
    if ($row['bad_good_return'] == "bad" && !empty($row['images'])) {
        $orderData["images"] = explode(",", $row['images']); // Images ko array me convert karna
    }

    $response["data"][] = $orderData;
}

// Agar koi data nahi mila to empty response dega
if (empty($response["data"])) {
    $response["success"] = false;
    $response["message"] = "No completed orders found for this seller";
}

echo json_encode($response);
?>
