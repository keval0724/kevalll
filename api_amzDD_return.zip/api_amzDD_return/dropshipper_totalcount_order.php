<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');

include('db.php');

try {
    // ✅ Validate seller_id
    if (!isset($_GET['seller_id']) || !is_numeric($_GET['seller_id'])) {
        throw new Exception("Missing or invalid seller_id parameter");
    }

   // NEW
    $seller_id = trim($_GET['seller_id']);


    // ✅ Fetch seller name from dropshippers table
    // $stmt_seller = $conn->prepare("SELECT seller_name FROM dropshippers WHERE id = ? LIMIT 1");
    // $stmt_seller->bind_param("i", $seller_id); // "i" for integer
    $stmt_seller = $conn->prepare("SELECT seller_name FROM dropshippers WHERE seller_id = ? LIMIT 1");
    $stmt_seller->bind_param("s", $seller_id); // "s" = string

    $stmt_seller->execute();
    $result_seller = $stmt_seller->get_result();

    if ($result_seller->num_rows === 0) {
        throw new Exception("Seller not found");
    }

    $seller_row = $result_seller->fetch_assoc();
    $seller_name = $seller_row['seller_name'];

    // ✅ Fetch order statistics
    $stmt_summary = $conn->prepare("
        SELECT 
            COUNT(DISTINCT amazon_order_id) AS total_orders,
            COUNT(return_tracking_id) AS total_tracking_ids,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
            COUNT(DISTINCT otp) AS otp_count
        FROM order_tracking 
        WHERE seller_id = ?
    ");
    $stmt_summary->bind_param("i", $seller_id);
    $stmt_summary->execute();
    $summary_result = $stmt_summary->get_result();
    $summary = $summary_result->fetch_assoc();

    // ✅ Prepare and return JSON
    echo json_encode([
        'success' => true,
        'data' => [
            'seller_name' => $seller_name,
            'total_orders' => (int) ($summary['total_orders'] ?? 0),
            'total_tracking_ids' => (int) ($summary['total_tracking_ids'] ?? 0),
            'pending' => (int) ($summary['pending'] ?? 0),
            'completed' => (int) ($summary['completed'] ?? 0),
            'otp_count' => (int) ($summary['otp_count'] ?? 0),
        ]
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
