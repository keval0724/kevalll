<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Only POST method is allowed']);
    exit;
}

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    $tracking_id = isset($_POST['tracking_id']) ? trim($_POST['tracking_id']) : null;
    $bad_good_return = isset($_POST['bad_good_return']) ? trim($_POST['bad_good_return']) : null;
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';

    if (empty($tracking_id)) {
        echo json_encode(['status' => 'error', 'message' => 'tracking_id is required']);
        exit;
    }

    // File upload paths
    $sticker_photo_path = '';
    $unbox_photo_path = '';

    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Handle sticker_photo
   if (isset($_FILES['sticker_photo']) && $_FILES['sticker_photo']['error'] === UPLOAD_ERR_OK) {
    $ext = pathinfo($_FILES['sticker_photo']['name'], PATHINFO_EXTENSION);
    $newName = 'sticker_' . uniqid() . '.' . $ext;
    $targetPath = $uploadDir . $newName;
    move_uploaded_file($_FILES['sticker_photo']['tmp_name'], $targetPath);
    $sticker_photo_path = $public_url_base . $targetPath; // ✅ prepend base URL here
}
    
    // // Handle unbox_photo
    // if (isset($_FILES['unbox_photo']) && $_FILES['unbox_photo']['error'] === UPLOAD_ERR_OK) {
    //     $ext = pathinfo($_FILES['unbox_photo']['name'], PATHINFO_EXTENSION);
    //     $newName = 'unbox_' . uniqid() . '.' . $ext;
    //     $targetPath = $uploadDir . $newName;
    //     move_uploaded_file($_FILES['unbox_photo']['tmp_name'], $targetPath);
    //     $unbox_photo_path = $targetPath;
    // }
 if (isset($_FILES['unbox_photo']) && $_FILES['unbox_photo']['error'] === UPLOAD_ERR_OK) {
    $ext = pathinfo($_FILES['unbox_photo']['name'], PATHINFO_EXTENSION);
    $newName = 'sticker_' . uniqid() . '.' . $ext;
    $targetPath = $uploadDir . $newName;
    move_uploaded_file($_FILES['unbox_photo']['tmp_name'], $targetPath);
    $sticker_photo_path = $public_url_base . $targetPath; // ✅ prepend base URL here
}
    // ✅ Handle multiple images only if damaged or used
    $image_urls = [];
    if (
        in_array($bad_good_return, ['damaged', 'used']) &&
        isset($_FILES['images']) &&
        is_array($_FILES['images']['tmp_name'])
    ) {
        $public_url_base = "https://customprint.deodap.com/uploads/";

        foreach ($_FILES['images']['tmp_name'] as $i => $tmp_name) {
            if (!empty($tmp_name)) {
                $error = $_FILES['images']['error'][$i];
                if ($error === UPLOAD_ERR_OK) {
                    $filename = time() . '_' . basename($_FILES['images']['name'][$i]);
                    $destination = $uploadDir . $filename;
                    if (move_uploaded_file($tmp_name, $destination)) {
                        $image_urls[] = $public_url_base . $filename;
                    }
                }
            }
        }
    }

    // ✅ Convert image_urls to JSON for storage
    $images_json = !empty($image_urls) ? json_encode($image_urls, JSON_UNESCAPED_SLASHES) : null;
    $updated_at = date('Y-m-d H:i:s');

    // Update query
    $stmt = $conn->prepare("
        UPDATE order_tracking 
        SET status = 'updated', 
            bad_good_return = ?, 
            remarks = ?, 
            sticker_photo = ?, 
            unbox_photo = ?, 
            images = ?, 
            updated_at = ?
        WHERE return_tracking_id = ? AND status = 'completed'
    ");
    $stmt->bind_param("sssssss", $bad_good_return, $remarks, $sticker_photo_path, $unbox_photo_path, $images_json, $updated_at, $tracking_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $fetchStmt = $conn->prepare("SELECT * FROM order_tracking WHERE return_tracking_id = ? AND status = 'updated'");
        $fetchStmt->bind_param("s", $tracking_id);
        $fetchStmt->execute();
        $result = $fetchStmt->get_result();
        $updatedOrder = $result->fetch_assoc();

        // Prepend full URL for single image paths
        $base_url = "https://customprint.deodap.com/";
        if (!empty($updatedOrder['sticker_photo'])) {
            $updatedOrder['sticker_photo'] = $base_url . $updatedOrder['sticker_photo'];
        }
        if (!empty($updatedOrder['unbox_photo'])) {
            $updatedOrder['unbox_photo'] = $base_url . $updatedOrder['unbox_photo'];
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'Order updated and fetched successfully',
            'data' => $updatedOrder
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No matching completed order found or no changes made.']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
