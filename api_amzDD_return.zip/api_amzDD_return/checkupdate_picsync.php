<?php
header('Content-Type: application/json');

// The version you want to match
$required_version = '1.5.0'; 

// Get version number from the request (POST data or GET query string)
$received_version = isset($_POST['version']) ? $_POST['version'] : '';  // Use $_POST for POST requests, $_GET for GET requests

$response = array();

// Check if received versi on matches the required version
if ($received_version === $required_version) {
    // Version matches, success response
    $response['status'] = 'success';
    $response['message'] = 'Version match.Update available';    
    $response['image_url'] = "https://customprint.deodap.com/amz_dd_return/uploads/update_dailog_new.jpg"; // Your actual image URL
} else {
    // Version mismatch, error response
    $response['status'] = 'error';
    $response['message'] = 'Version mismatch.No Update available';
}

echo json_encode($response);
?>
