<?php
// Set response headers
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Allow only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Only POST method is allowed"
    ]);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Extract and validate input
$email = trim($input['email'] ?? '');
$password = trim($input['password'] ?? '');

if (empty($email) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "Email and password are required"
    ]);
    exit;
}

// In production, fetch from secure database
$validEmail = "admin@deodap.com";
$validPassword = "admin@071106";

// Compare credentials
if ($email === $validEmail && $password === $validPassword) {
    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "data" => [
            "email" => $validEmail,
            "role" => "admin"
        ]
    ]);
    exit;
}

// Invalid login
echo json_encode([
    "success" => false,
    "message" => "Invalid email or password"
]);
exit;
