<?php
header('Content-Type: application/json');

// Static response data
$response = [
    "success" => true,
    "screen" => [
        "link" => "https://drive.google.com/file/d/1G_P4FHnWSC1_t_KYStao_sQCnR3Q9r9S/view?usp=sharing" // Replace with your actual link
    ]
];

// Return the response as JSON
echo json_encode($response);
?>
