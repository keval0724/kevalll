<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

include('db.php');
header('Content-Type: application/json');

try {
    if (!$conn) {
        throw new Exception("Database Connection Failed: " . mysqli_connect_error());
    }

    if (!isset($_GET['tracking_id']) || empty($_GET['tracking_id']) || !is_numeric($_GET['tracking_id'])) {
        throw new Exception("Valid Tracking ID (Auto-Increment ID) is required in the URL");
    }

    $tracking_id = intval($_GET['tracking_id']);

    if (!isset($_POST['amazon_order_ids'], $_POST['return_tracking_ids'], $_POST['otp'])) {
        throw new Exception("Missing required fields: amazon_order_ids, return_tracking_ids, otp");
    }

    $amazon_order_id = trim($_POST['amazon_order_ids']);
    $return_tracking_id = trim($_POST['return_tracking_ids']);
    $otp = trim($_POST['otp']);

    if (empty($amazon_order_id) || empty($return_tracking_id) || empty($otp)) {
        throw new Exception("Form fields cannot be empty");
    }

    // ✅ Check if Tracking ID exists
    $stmt = $conn->prepare("SELECT id FROM order_tracking WHERE id = ?");
    if (!$stmt) {
        throw new Exception("SQL Error (Tracking ID Check): " . $conn->error);
    }
    $stmt->bind_param("i", $tracking_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Tracking ID not found");
    }

    // ✅ Check if return_tracking_id is unique
    $stmt_check = $conn->prepare("SELECT id FROM order_tracking WHERE return_tracking_id = ? AND id != ?");
    if (!$stmt_check) {
        throw new Exception("SQL Error (Duplicate Tracking Check): " . $conn->error);
    }
    $stmt_check->bind_param("si", $return_tracking_id, $tracking_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        throw new Exception("Duplicate Tracking ID not allowed");
    }

    // ✅ Update order_tracking table
    $update_stmt = $conn->prepare("UPDATE order_tracking SET amazon_order_id = ?, return_tracking_id = ?, otp = ? WHERE id = ?");
    if (!$update_stmt) {
        throw new Exception("SQL Error (Update Tracking): " . $conn->error);
    }
    $update_stmt->bind_param("sssi", $amazon_order_id, $return_tracking_id, $otp, $tracking_id);
    $update_stmt->execute();

    echo json_encode([
        'success' => true,
        'message' => 'Tracking details updated successfully',
        'tracking_id' => $tracking_id
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
