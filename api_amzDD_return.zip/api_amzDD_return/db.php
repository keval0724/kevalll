<?php
// Database connection
$servername = "lms.cpcm5mpbdjt1.ap-south-1.rds.amazonaws.com";
$username = "vc01"; // default XAMPP username
$password = "Yx6Nbs0fer5gXLY"; // default XAMPP password
$dbname = "admin_amzDDreturn_deodap_com";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
