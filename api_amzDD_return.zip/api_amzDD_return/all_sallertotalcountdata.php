<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// ✅ Only allow GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(["success" => false, "message" => "Only GET method is allowed"]);
    exit;
}

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    // ✅ Get all pending orders with seller info
    $stmt = $conn->prepare("
        SELECT seller_id, seller_name, amazon_order_id, return_tracking_id, otp, created_at, status
        FROM order_tracking
        WHERE status = 'pending' AND seller_id IS NOT NULL
        ORDER BY seller_id, created_at DESC
    ");
    $stmt->execute();
    $result = $stmt->get_result();

    $grouped = [];

    while ($row = $result->fetch_assoc()) {
        $seller_id = $row['seller_id'];
        $grouped[$seller_id][] = [
            "seller_id" => $seller_id,
            "seller_name" => $row['seller_name'],
            "amazon_order_id" => $row['amazon_order_id'],
            "return_tracking_id" => $row['return_tracking_id'],
            "otp" => $row['otp'],
            "created_at" => $row['created_at'],
            "status" => $row['status']
        ];
    }

    echo json_encode([
        "success" => true,
        "sellers" => $grouped
    ], JSON_PRETTY_PRINT);
    exit;

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
    exit;
}
