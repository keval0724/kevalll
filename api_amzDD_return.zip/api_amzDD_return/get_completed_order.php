<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Only POST method allowed"]);
    exit;
}

// ✅ Input Validation
$tracking_id = trim($_POST['tracking_id'] ?? '');
if (empty($tracking_id)) {
    echo json_encode(["status" => "error", "message" => "Tracking ID is required"]);
    exit;
}

// ✅ Query to find orders with this tracking ID
$stmt = $conn->prepare("SELECT * FROM order_tracking WHERE return_tracking_id = ?");
$stmt->bind_param("s", $tracking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "No order found for this tracking ID"]);
    $stmt->close();
    $conn->close();
    exit;
}

$orders = [];
foreach ($result as $row) {
    if ($row['status'] === 'complete') {
        echo json_encode(["status" => "error", "message" => "This tracking ID process is already completed"]);
        $stmt->close();
        $conn->close();
        exit;
    }
    if ($row['status'] === 'pending') {
        $orders[] = $row;
    }
}

$stmt->close();
$conn->close();

if (!empty($orders)) {
    echo json_encode(["status" => "success", "data" => $orders]);
} else {
    echo json_encode(["status" => "error", "message" => "No pending orders found for this tracking ID"]);
}
?>
