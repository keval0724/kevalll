<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
include('db.php');

// Debugging: Check what data is received
$data = json_decode(file_get_contents("php://input"), true);
$receivedData = !empty($_POST) ? $_POST : $data;
if (empty($receivedData)) {
    echo json_encode(['message' => 'No data received!', 'debug' => $receivedData]);
    exit;
}

// Extract data from both JSON & Form-Data
$email = isset($_POST['email']) ? trim($_POST['email']) : (isset($data['email']) ? trim($data['email']) : null);
$otp = isset($_POST['otp']) ? trim($_POST['otp']) : (isset($data['otp']) ? trim($data['otp']) : null);

if (!$email || !$otp) {
    echo json_encode(['message' => 'Email and OTP required!', 'debug' => $receivedData]);
    exit;
}

// OTP Verification
$stmt = $conn->prepare("SELECT * FROM deodapemp_user_otp_verification WHERE email = ? AND otp = ? AND expires_at > NOW()");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Check if User already exists
    $checkUser = $conn->prepare("SELECT * FROM deodapemp_users_register WHERE email = ?");
    $checkUser->bind_param("s", $email);
    $checkUser->execute();
    $userExists = $checkUser->get_result()->num_rows > 0;

    if (!$userExists) {
        // Validate Additional Data
        $seller_name = isset($_POST['EMP_name']) ? trim($_POST['EMP_name']) : (isset($data['EMP_name']) ? trim($data['EMP_name']) : null);
        $contact_number = isset($_POST['contact_number']) ? trim($_POST['contact_number']) : (isset($data['contact_number']) ? trim($data['contact_number']) : null);
        $password = isset($_POST['password']) ? $_POST['password'] : (isset($data['password']) ? $data['password'] : null);

        if (!$seller_name || !$contact_number || !$password) {
            echo json_encode(['message' => 'Missing required fields!', 'debug' => $receivedData]);
            exit;
        }

        $password = password_hash($password, PASSWORD_BCRYPT);
        $register_timestamp = date('Y-m-d H:i:s');

        // Insert User
        $insertUser = $conn->prepare("INSERT INTO deodapemp_users_register (EMP_name, contact_number, email, password, register_timestamp) VALUES (?, ?, ?, ?, ?)");
        $insertUser->bind_param("sssss", $seller_name, $contact_number, $email, $password, $register_timestamp);
        $insertUser->execute();
    }

    // Delete OTP after verification
    $deleteOTP = $conn->prepare("DELETE FROM deodapemp_user_otp_verification WHERE email = ?");
    $deleteOTP->bind_param("s", $email);
    $deleteOTP->execute();

    echo json_encode(['success' => 'OTP Verified & Registration Completed!']);
} else {
    echo json_encode(['message' => 'Invalid or expired OTP!', 'debug' => $receivedData]);
}
?>
