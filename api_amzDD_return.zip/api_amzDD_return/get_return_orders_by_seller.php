<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');
include('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

try {
    if (!isset($_GET['seller_id'])) {
        throw new Exception("Missing required parameter: seller_id");
    }

    $seller_id = trim($_GET['seller_id']);
    $status_filter = isset($_GET['status']) ? trim($_GET['status']) : 'all';
    $date_filter = isset($_GET['date_filter']) ? trim($_GET['date_filter']) : null;

    // ✅ Check seller_id in the correct column only
    $stmt_seller = $conn->prepare("SELECT id FROM dropshippers WHERE seller_id = ? LIMIT 1");
    if (!$stmt_seller) {
        throw new Exception("SQL Error (Seller Check): " . $conn->error);
    }
    $stmt_seller->bind_param("s", $seller_id);
    $stmt_seller->execute();
    $result_seller = $stmt_seller->get_result();

    if ($result_seller->num_rows === 0) {
        throw new Exception("Seller not found");
    }

    // ✅ Build order query
    $query = "
        SELECT 
            id,
            COALESCE(amazon_order_id, 'null') AS amazon_order_id,
            COALESCE(return_tracking_id, 'null') AS return_tracking_id,
            COALESCE(otp, 'null') AS otp,
            COALESCE(out_for_delivery_date, 'null') AS out_for_delivery_date,
            COALESCE(bad_good_return, 'null') AS bad_good_return,
            COALESCE(images, 'null') AS images,
            created_at,
            status
        FROM order_tracking
        WHERE seller_id = ?
    ";

    $types = "s";
    $params = [$seller_id];

    if ($status_filter !== 'all') {
        $query .= " AND status = ?";
        $types .= "s";
        $params[] = $status_filter;
    }

    if ($date_filter === 'today') {
        $query .= " AND DATE(created_at) = CURDATE()";
    } elseif ($date_filter === 'last_week') {
        $query .= " AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    } elseif ($date_filter === 'last_month') {
        $query .= " AND created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
    }

    $query .= " ORDER BY created_at DESC";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("SQL Error (Order Fetch): " . $conn->error);
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    if (empty($orders)) {
        throw new Exception("No orders found");
    }

    echo json_encode([
        'success' => true,
        'data' => $orders
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
