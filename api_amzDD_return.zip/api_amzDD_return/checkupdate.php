<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('db.php');

$input = json_decode(file_get_contents("php://input"), true);
$role = trim($input['role'] ?? '');
$app_version = trim($input['version'] ?? '');

if (empty($role) || empty($app_version)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Missing version or role.'
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT version, image_url, download_url FROM app_version WHERE role = ? ORDER BY id DESC LIMIT 1");
$stmt->bind_param("s", $role);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    if ($row['version'] === $app_version) {
        echo json_encode([
            'status' => 'success',
            'message' => 'App is up to date.'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Update available.',
            'latest_version' => $row['version'],
            'image_url' => $row['image_url'],
            'download_url' => $row['download_url']
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'No version found for this role.'
    ]);
}
exit;
