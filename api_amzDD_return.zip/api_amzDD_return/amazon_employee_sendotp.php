<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('db.php');
require_once __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kolkata');

function generateOTP($length = 6) {
    return substr(str_shuffle('0123456789'), 0, $length);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email address']);
        exit;
    }

    // Check if email exists
    $stmt = $conn->prepare("SELECT * FROM dropshippers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => "Email doesn't exist in the system"]);
        exit;
    }

    $otp = generateOTP();
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    // Optional: Clear existing OTP
    $stmt = $conn->prepare("UPDATE dropshippers SET otp = ?, otp_expires_at = ? WHERE email = ?");
    $stmt->bind_param("sss", $otp, $expires_at, $email);
    $stmt->execute();

    // Send OTP via email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'keval.deodap@gmail.com';
        $mail->Password   = 'npwu glms yxwx gagp'; // App password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('keval.deodap@gmail.com', 'OTP Verification');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body    = "<h2>OTP for verification: <b>$otp</b></h2><p>This OTP will expire in 10 minutes.</p>";

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'OTP sent successfully', 'otp_send_to' => $email]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Email is required and method must be POST']);
}
?>
