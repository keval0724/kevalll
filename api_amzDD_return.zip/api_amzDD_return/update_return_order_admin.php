<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require 'db_connection.php'; // 🔁 તમારી db ફાઇલનું નામ સાચું હોવું જોઈએ

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

$tracking_id = $_POST['tracking_id'] ?? '';

if (empty($tracking_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Tracking ID is required']);
    exit;
}

// ✅ Fetch only completed order with given tracking_id
$sql = "SELECT * FROM order_tracking WHERE return_tracking_id = ? AND status = 'completed' LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $tracking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();

    // 📷 Decode images if present
    $order['images'] = !empty($order['images']) ? json_decode($order['images'], true) : [];

    echo json_encode([
        'status' => 'success',
        'data' => $order
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'This tracking ID is not completed yet or not found.'
    ]);
}

$stmt->close();
$conn->close();
