<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('db.php');
require_once __DIR__ . '/vendor/autoload.php'; // PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kolkata');

function generateOTP($length = 6) {
    return substr(str_shuffle('0123456789'), 0, $length);
}

// Get raw JSON input if available
$data = json_decode(file_get_contents("php://input"), true);

// Check if request is JSON or Form-Data
$EMP_name = isset($_POST['EMP_name']) ? trim($_POST['EMP_name']) : (isset($data['EMP_name']) ? trim($data['EMP_name']) : null);
$contact_number = isset($_POST['contact_number']) ? trim($_POST['contact_number']) : (isset($data['contact_number']) ? trim($data['contact_number']) : null);
$email = isset($_POST['email']) ? trim($_POST['email']) : (isset($data['email']) ? trim($data['email']) : null);
$password = isset($_POST['password']) ? $_POST['password'] : (isset($data['password']) ? $data['password'] : null);

if (!$EMP_name || !$contact_number || !$email || !$password) {
    echo json_encode(['message' => 'All fields are required!']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['message' => 'Invalid email address!']);
    exit;
}

// Check if email already exists
$checkEmail = $conn->prepare("SELECT * FROM deodapemp_users_register WHERE email = ?");
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$result = $checkEmail->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['message' => 'Email already registered!']);
    exit;
}

// Generate OTP
$otp = generateOTP();
$expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

// Store OTP in the database
$stmt = $conn->prepare("INSERT INTO deodapemp_user_otp_verification (email, otp, expires_at) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $otp, $expires_at);
$stmt->execute();

// Send OTP via email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'keval.deodap@gmail.com';
    $mail->Password = 'elxp ivjm zdwr xdls'; // Use App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;

    // Disable SSL verification (for development only)
    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    $mail->setFrom('deodapyash@gmail.com', 'OTP Verification');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Your OTP Code';
    $mail->Body = "Your OTP for registration is <b>$otp</b>. It is valid for 10 minutes.";

    $mail->send();
    echo json_encode(['message' => 'OTP sent successfully','email' => $email, 'EMP_name' => $EMP_name, 'contact_number' => $contact_number, 'password' => $password]);
} catch (Exception $e) {
    echo json_encode(['message' => 'Mail error: ' . $mail->ErrorInfo]);
}

$conn->close();
?>
