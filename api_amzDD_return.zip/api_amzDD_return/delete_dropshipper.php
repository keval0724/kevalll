<?php
require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Ensure only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST method is allowed']);
    exit;
}

$seller_id = trim($_POST['seller_id'] ?? '');

if (empty($seller_id)) {
    echo json_encode(['success' => false, 'error' => 'Seller ID is required']);
    exit;
}

// Secure deletion with prepared statement
$stmt = $conn->prepare("DELETE FROM dropshippers WHERE seller_id = ?");
$stmt->bind_param("s", $seller_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Dropshipper deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'No such seller found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Deletion failed']);
}

$stmt->close();
$conn->close();
exit;
