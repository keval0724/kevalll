<?php
// टाइमज़ोन सेट करें
date_default_timezone_set('Asia/Kolkata');

// डेटाबेस कनेक्शन
include('db.php');
header('Content-Type: application/json');

if (isset($_POST['email']) && isset($_POST['otp'])) {
    $email = trim($_POST['email']);
    $otp = trim($_POST['otp']);
    
    // OTP चेक करें कि सही है और एक्सपायर नहीं हुआ
    $stmt = $conn->prepare("SELECT * FROM dropshiper_resetpassword_otp WHERE email = ? AND otp = ? AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // अगर OTP सही है तो वेरिफिकेशन सक्सेसफुल और एंट्री डिलीट करें
        $deleteStmt = $conn->prepare("DELETE FROM dropshiper_resetpassword_otp WHERE email = ?");
        $deleteStmt->bind_param("s", $email);
        $deleteStmt->execute();

        echo json_encode([
            'success' => 'OTP verified successfully and deleted from database',
        ]);
    } else {
        // OTP ग़लत है या एक्सपायर हो गया
        echo json_encode([
            'error' => 'OTP Invalid or Expired!',
        ]);
    }
} else {
    // अगर email या otp नहीं मिला तो एरर भेजें
    echo json_encode([
        'error' => 'Email and OTP are required!',
    ]);
}
?>
