<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('db.php');  // Database Connection

require_once __DIR__ . '/vendor/autoload.php';  // PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kolkata');

function generateOTP($length = 6) {
    return substr(str_shuffle('0123456789'), 0, $length);
}

if (isset($_POST['email'])) {
    $email = $_POST['email'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['message' => 'Invalid email address!']);
        exit;
    }

    // ईमेल को दोनों टेबल में चेक करें
    $stmt = $conn->prepare("SELECT email FROM dropshipper_register WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['message' => "Email doesn't exist"]);
        exit;
    }

    // OTP जनरेट करें
    $otp = generateOTP();
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes')); // अब यह सही तरीके से एक्सपायरी टाइम सेट करेगा

$stmt = $conn->prepare("INSERT INTO dropshiper_resetpassword_otp (email, otp, expires_at) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $otp, $expires_at);
$stmt->execute();

    // ईमेल पर भेजें
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'yashkalani13@gmail.com';  
        $mail->Password = 'fbbo bmmu ruxk mnee';  
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('yashkalani13@gmail.com', 'OTP Verification');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "<h1>Your OTP is: <b>$otp</b></h1>";

        $mail->send();

        echo json_encode(['message' => 'OTP sent successfully', 'otp_send_to' => $email]);
    } catch (Exception $e) {
        echo json_encode(['message' => 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo]);
    }
} else {
    echo json_encode(['message' => 'Email is required!']);
}
?>
