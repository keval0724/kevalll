<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Only POST method is allowed']);
    exit;
}

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    $tracking_id = isset($_POST['tracking_id']) ? trim($_POST['tracking_id']) : null;

    if (empty($tracking_id)) {
        echo json_encode(['status' => 'error', 'message' => 'tracking_id is required']);
        exit;
    }

    // Fetch updated order data only
    $stmt = $conn->prepare("SELECT * FROM order_tracking WHERE status = 'updated' AND return_tracking_id = ?");
    $stmt->bind_param("s", $tracking_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $updatedOrder = $result->fetch_assoc();

    if (!$updatedOrder) {
        echo json_encode(['status' => 'error', 'message' => 'No matching updated order found']);
        exit;
    }

    echo json_encode(['status' => 'success', 'data' => $updatedOrder]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
