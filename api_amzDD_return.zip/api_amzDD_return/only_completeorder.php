<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['status' => 'error', 'message' => 'Only GET method is allowed']);
    exit;
}

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    $tracking_id = isset($_GET['tracking_id']) ? $_GET['tracking_id'] : null;

    if ($tracking_id) {
        // 🔍 Fetch single order
        $stmt = $conn->prepare("SELECT * FROM order_tracking WHERE status = 'completed' AND return_tracking_id = ?");
        $stmt->bind_param("s", $tracking_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $order = $result->fetch_assoc();

        if ($order) {
            // Decode image JSON array if needed
            $order['images'] = !empty($order['images']) ? json_decode($order['images'], true) : [];
            echo json_encode(['status' => 'success', 'data' => $order]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No matching order found']);
        }

    } else {
        // 📦 Fetch all grouped completed orders
        $stmt = $conn->prepare("SELECT * FROM order_tracking WHERE status = 'completed' ORDER BY seller_id, created_at DESC");
        $stmt->execute();
        $result = $stmt->get_result();

        $grouped = [];

        while ($row = $result->fetch_assoc()) {
            $sid = $row['seller_id'];
            $row['images'] = !empty($row['images']) ? json_decode($row['images'], true) : [];
            $grouped[$sid][] = $row;
        }

        echo json_encode(['status' => 'success', 'sellers' => $grouped], JSON_PRETTY_PRINT);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
