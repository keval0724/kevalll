<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');
include('db.php');
header('Content-Type: application/json');

try {
    // ✅ Check if seller_id is provided
    if (!isset($_GET['seller_id'])) {
        throw new Exception("Missing required parameter: seller_id");
    }

    $seller_id = trim($_GET['seller_id']);
    $date_filter = isset($_POST['date_filter']) ? trim($_POST['date_filter']) : null;

    // ✅ Check database connection
    if (!$conn) {
        throw new Exception("Database Connection Failed: " . mysqli_connect_error());
    }

    // ✅ Base query (sirf "pending" status wale orders fetch honge)
    $query = "
        SELECT id, 
               order_id, 
               COALESCE(amazon_order_id, 'null') AS amazon_order_id, 
               COALESCE(return_tracking_id, 'null') AS return_tracking_id, 
               COALESCE(otp, 'null') AS otp, 
               COALESCE(status, 'null') AS status, 
               created_at
        FROM order_tracking 
        WHERE seller_id = ? AND status = 'pending'
    ";

    // ✅ Date filter conditions
    if ($date_filter === 'today') {
        $query .= " AND DATE(created_at) = CURDATE()";
    } elseif ($date_filter === 'last_week') {
        $query .= " AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    } elseif ($date_filter === 'last_month') {
        $query .= " AND created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
    }

    $query .= " ORDER BY created_at DESC";

    $stmt = $conn->prepare($query);

    if (!$stmt) {
        throw new Exception("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("s", $seller_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    // ✅ Check if data exists
    if (empty($orders)) {
        throw new Exception("No pending orders found");
    }

    echo json_encode(['success' => true, 'data' => $orders], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
