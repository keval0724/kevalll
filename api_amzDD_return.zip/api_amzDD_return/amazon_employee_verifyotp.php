<?php
include 'db.php';
header('Content-Type: application/json');
date_default_timezone_set('Asia/Kolkata');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method. Use POST.']);
    exit;
}

if (empty($_POST['email']) || empty($_POST['otp'])) {
    echo json_encode(['success' => false, 'message' => 'Email and OTP are required!']);
    exit;
}

$email = trim($_POST['email']);
$otp = trim($_POST['otp']);

$stmt = $conn->prepare("SELECT otp, otp_expires_at FROM dropshippers WHERE email = ? AND otp = ?");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid OTP or email not found']);
    exit;
}

$row = $result->fetch_assoc();
if (strtotime($row['otp_expires_at']) < time()) {
    echo json_encode(['success' => false, 'message' => 'OTP expired']);
    exit;
}

// OTP is valid, mark as verified
$stmt = $conn->prepare("UPDATE dropshippers SET is_verified = 1, otp = NULL, otp_expires_at = NULL WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();

echo json_encode(['success' => true, 'message' => 'OTP verified successfully']);
?>
