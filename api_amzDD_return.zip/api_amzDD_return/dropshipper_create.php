<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once("db.php"); // Move DB connection to a secure db.php file

// Read input
$seller_name     = trim($_POST['seller_name'] ?? '');
$store_name      = trim($_POST['store_name'] ?? '');
$contact_number  = trim($_POST['contact_number'] ?? '');
$email           = trim($_POST['email'] ?? '');
$crn             = trim($_POST['crn'] ?? '');

// Validate required fields
if (empty($seller_name) || empty($store_name) || empty($contact_number) || empty($email) || empty($crn)) {
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email format."]);
    exit;
}

// Check if dropshipper already exists
$check = $conn->prepare("SELECT id FROM dropshippers WHERE contact_number = ? OR email = ? OR crn = ?");
$check->bind_param("sss", $contact_number, $email, $crn);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Dropshipper already exists with same contact, email or CRN."]);
    $check->close();
    exit;
}
$check->close();

// Generate seller_id
$result = $conn->query("SELECT MAX(CAST(seller_id AS UNSIGNED)) AS max_id FROM dropshippers");
$row = $result->fetch_assoc();
$next_id = $row['max_id'] ? $row['max_id'] + 1 : 10001;
$seller_id = strval($next_id);

// Generate password
$plain_password = bin2hex(random_bytes(4)); // 8-char password
$hashed_password = password_hash($plain_password, PASSWORD_BCRYPT);

// Set username same as contact number
$username = $contact_number;

// Insert into database
$stmt = $conn->prepare("INSERT INTO dropshippers 
    (seller_id, seller_name, store_name, contact_number, username, email, crn, password) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $seller_id, $seller_name, $store_name, $contact_number, $username, $email, $crn, $hashed_password);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Dropshipper registered.",
        "seller_id" => $seller_id,
        "username" => $username,
        "password" => $plain_password
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Insert failed."
        // In production, avoid exposing SQL errors
        // "sql_error" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
exit;
