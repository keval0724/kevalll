<?php
require_once('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode([
        "success" => false,
        "message" => "Only GET method is allowed"
    ]);
    exit;
}

try {
    $query = "SELECT id, seller_id, seller_name, store_name, contact_number, email, crn, username, last_login, created_at FROM dropshippers ORDER BY id DESC";
    $result = $conn->query($query);

    $dropshippers = [];

    while ($row = $result->fetch_assoc()) {
        $dropshippers[] = [
            "seller_id"      => $row['seller_id'],
            "seller_name"    => $row['seller_name'],
            "store_name"     => $row['store_name'],
            "contact_number" => $row['contact_number'],
            "email"          => $row['email'],
            "crn"            => $row['crn'],
            "username"       => $row['username'],
            "last_login"     => $row['last_login'],
            "created_at"     => $row['created_at']
        ];
    }

    echo json_encode([
        "success" => true,
        "dropshippers" => $dropshippers
    ]);
    exit;

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Failed to fetch dropshippers.",
        "error" => $e->getMessage()
    ]);
    exit;
}
