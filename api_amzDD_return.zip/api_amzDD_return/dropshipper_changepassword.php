<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('db.php');
date_default_timezone_set('Asia/Kolkata');

// Check if form-data fields are present
if (!isset($_POST['email'], $_POST['new_password'], $_POST['confirm_password'])) {
    echo json_encode(['message' => 'Email, new password, and confirm password are required!']);
    exit;
}

// Get form-data inputs
$email = trim($_POST['email']);
$new_password = trim($_POST['new_password']);
$confirm_password = trim($_POST['confirm_password']);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['message' => 'Invalid email address!']);
    exit;
}

// Check if passwords match
if ($new_password !== $confirm_password) {
    echo json_encode(['message' => 'Passwords do not match!']);
    exit;
}

// Hash the new password
$hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

// Check if email exists in the database
$stmt = $conn->prepare("SELECT * FROM dropshipper_register WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update password
    $updateStmt = $conn->prepare("UPDATE dropshipper_register SET password = ? WHERE email = ?");
    $updateStmt->bind_param("ss", $hashed_password, $email);
    if ($updateStmt->execute()) {
        echo json_encode(['success' => 'Password updated successfully!']);
    } else {
        echo json_encode(['message' => 'Failed to update password!']);
    }
} else {
    echo json_encode(['message' => 'User not found!']);
}

$conn->close();
?>
