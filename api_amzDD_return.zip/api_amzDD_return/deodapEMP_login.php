<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if (!$conn) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Auto-create admin if not exists
$admin_stmt = $conn->prepare("SELECT * FROM deodap_emp_login WHERE email = 'admin@deodap.com' LIMIT 1");
$admin_stmt->execute();
$admin_result = $admin_stmt->get_result();

if ($admin_result->num_rows === 0) {
    $default_password = 'admin@123789'; // Store as plain text for now
    $email = 'admin@deodap.com';

    $insert_stmt = $conn->prepare("INSERT INTO deodap_emp_login (email, password) VALUES (?, ?)");
    $insert_stmt->bind_param("ss", $email, $default_password);
    $insert_stmt->execute();
    $insert_stmt->close();

    $admin_stmt->execute();
    $admin_result = $admin_stmt->get_result();
}
$admin_stmt->close();

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method! Must be POST');
    }

    if (!isset($_POST['email'], $_POST['password'])) {
        throw new Exception('Email and password are required!');
    }

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        throw new Exception('Email and password cannot be empty!');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format!');
    }

    if (strlen($password) < 8) {
        throw new Exception('Password must be at least 8 characters long!');
    }

    $stmt = $conn->prepare("SELECT * FROM deodap_emp_login WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // TEMPORARY: Plain text password check
        if ($password === $user['password']) {
            session_start();
            $_SESSION['admin_email'] = $email;
            $_SESSION['login_time'] = date('Y-m-d H:i:s');

            $updateStmt = $conn->prepare("UPDATE deodap_emp_login SET last_login = NOW() WHERE email = ?");
            $updateStmt->bind_param("s", $email);
            $updateStmt->execute();
            $updateStmt->close();

            echo json_encode([
                'success' => true,
                'message' => 'Login successful',
                'email' => htmlspecialchars($email),
                'session_id' => session_id()
            ]);
        } else {
            throw new Exception('Invalid password!');
        }
    } else {
        throw new Exception('Invalid email!');
    }

    $stmt->close();
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
