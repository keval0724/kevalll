<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Kolkata');

include('db.php');
header('Content-Type: application/json');

try {
    if (!isset($_GET['seller_id'])) {
        throw new Exception("Missing required parameter: seller_id");
    }

    $seller_id = intval($_GET['seller_id']);
    
    // ✅ Filter parameters
    $filter = isset($_GET['filter']) ? trim($_GET['filter']) : ''; // "good", "bad", या empty (default all)

    // ✅ Base query (अब status भी select हो रहा है)
    $query = "SELECT return_tracking_id, amazon_order_id, otp, bad_good_return, images, seller_name, status, created_at 
              FROM order_tracking 
              WHERE seller_id = ?";

    // ✅ Filter conditions
    if ($filter === 'good') {
        $query .= " AND bad_good_return = 'good'";
    } elseif ($filter === 'bad') {
        $query .= " AND bad_good_return = 'bad'";
    }

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("i", $seller_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $row['images'] = $row['images'] ? json_decode($row['images'], true) : [];
        $orders[] = $row;
    }
    
    // ✅ Seller Name Extract
    $seller_name = "";
    if (!empty($orders)) {
        $seller_name = $orders[0]['seller_name'];
        foreach ($orders as &$order) {
            unset($order['seller_name']); // Orders से seller_name हटा दिया
        }
    } else {
        throw new Exception("Seller ID not found or no orders available");
    }

    echo json_encode([
        "success"        => true,
        "seller_id"      => $seller_id,
        "seller_name"    => $seller_name,
        "scanned_orders" => $orders
    ], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
